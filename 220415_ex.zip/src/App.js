import './App.css';
import {useState, useEffect} from 'react';
import srcData from './srcData';
import {Card, Button} from 'react-bootstrap';
import { Switch, Route, Link, useParams, useHistory} from 'react-router-dom';
import SecContainer  from './SecContainer';
import axios from 'axios';

function Footer(props) {
  return (
    <footer onClick={props.onClick}>
      푸터
    </footer>
  );
}

function Input(props){
  return (
    <input type="text" onChange={(event)=>{
      props.onChange(event);
    }}/>
  );
}

function fnGetData(wear, wearChange){
  const axios = require('axios');
  // 지정된 ID를 가진 유저에 대한 요청

  //axios.get(URL).then(성공).catch(실패);
  axios.get('https://kimsrik.github.io/react-server/serverData.json')
  .then((res)=>{
    wearChange([...wear, ...res.data]);
    console.log(wear);
  })
  .catch((err)=>{
    console.log('실패');
  })
  
}


function App() {
  let [wear, wearChange] = useState(srcData);
  return (    
    <div className="App">  
      
        <Link to="/">홈으로</Link>
        <Link to="/sec1">sec1으로</Link>
        <Link to="/sec2">sec2으로</Link>
        
      <Switch>
        <Route path="/sec1/:num">
          <Detail wear={wear} wearChange={wearChange}></Detail>
        </Route>
        <Route path="/sec1">
          <section>
            <Input onChange={(t)=>{console.log(t.target.value)}}/>
            <button>클릭</button>
            <SecContainer wear={wear} wearChange={wearChange}/>
            <button onClick={()=>{fnGetData(wear, wearChange)}}>3개 더</button>
          </section>  
        </Route>
        <Route path="/sec2">
          <section>
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="holder.js/100px180" />
            <Card.Body>
              <Card.Title>Card Title</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          </section>
        </Route>
        <Route path="/">
          <header>
            <h1>쇼핑몰</h1>
          </header>
        </Route>      
      </Switch>

      

      <Footer onClick={()=>{
      console.log('푸터')
    }}/>   
    </div>
  );
}

function Detail(props) {
  let {num} = useParams();
  let history = useHistory();
  let [box, boxChange] = useState(true);
  useEffect(()=>{
    let setInt = setTimeout(()=>{boxChange(false)},3000);
  });
  return (
    <div>
      <h1>{props.wear[num-1].title}</h1>
      {/* 2초 후에 사라짐 */}
      {
        box
        ? <p>재고가 얼마 없어요...</p>
        : null
      }
      <h1>{props.wear[num-1].content}</h1>
      <h1>{props.wear[num-1].price}</h1>
      <button onClick={()=>{history.go(-1)}}>뒤로가기</button>
    </div>
  );
}

export default App;

