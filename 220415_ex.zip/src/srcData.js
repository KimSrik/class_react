export default [
  {id: 1, title: '스키니진', content: '좋은 청바지입니다. 많이 구입해주세요.', price: '25,000원'},
  {id: 2, title: '월남치마', content: '월남에서 돌아온 치마입니다.', price: '12,000원'},
  {id: 3, title: '발목양말', content: '구제양말  특이사항(구멍있음)', price: '600원'}
];