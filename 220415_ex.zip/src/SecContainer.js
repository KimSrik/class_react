import { Link } from 'react-router-dom';
function SecContainer(props) {
  return (
    <div className="container">
      {
        props.wear.map((item, idx, arr)=>{
          return (
            <Link to={`/sec1/${item.id}`} key={item.id}>
              <div className="card">
                <h2>{item.title}</h2>
                <p>{item.content}</p>
                <p>{item.price}</p>
              </div>
            </Link>
          );
        })
      }
    </div>  
  );
}

export default SecContainer;